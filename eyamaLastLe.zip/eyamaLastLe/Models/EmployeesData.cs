﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eyamaLastLe.Models
{
    public class EmployeesData
    {
        public string EmployeeNumber { get; set; }
        public string Age { get; set; }
        public string Attrition { get; set; }
        public string BusinessTravel { get; set; }
        public string DistanceFromHome { get; set; }
        public string EnvironmentSatisfaction { get; set; }
        public string Gender { get; set; }
        public string MaritalStatus { get; set; }
        public string NumCompaniesWorked { get; set; }
        public string Over18 { get; set; }
    }
}
